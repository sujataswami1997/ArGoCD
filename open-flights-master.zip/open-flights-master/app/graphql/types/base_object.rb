module Types
  class BaseObject < GraphQL::Schema::Object
  end
end
